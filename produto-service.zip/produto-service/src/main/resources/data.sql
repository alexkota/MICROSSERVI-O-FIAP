INSERT INTO PRODUTO (produtoId, produtoName) values (1000, 'Café');
INSERT INTO PRODUTO (produtoId, produtoName) values (1001, 'Cerveja');